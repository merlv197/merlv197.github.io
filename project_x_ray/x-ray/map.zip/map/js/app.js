function myMap() {
      var mapProp= {
          center:new google.maps.LatLng(43.2698033,+5.386378199999967),
          zoom:9,

      };
      var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
      
      }


      